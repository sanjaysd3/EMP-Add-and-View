package com.emp.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.emp.bean.Employee;

@Repository
@Transactional
public class EmpDaoImpl implements IEmpDao{
	
	@PersistenceContext
	private EntityManager em;

	@Override
	public int addEmployeeDetails(Employee emp) {
		em.persist(emp);
		System.out.println(emp.getEmpId());
		return emp.getEmpId();
	}

	@Override
	public ArrayList<Employee> getAllEmployeeInfo() {
		Query qry=em.createNamedQuery("getAllEmployeeInfo");
		return (ArrayList<Employee>) qry.getResultList();
	}

}
