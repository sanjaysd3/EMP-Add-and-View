package com.emp.dao;

import java.util.ArrayList;

import com.emp.bean.Employee;

public interface IEmpDao {

	int addEmployeeDetails(Employee emp);

	ArrayList<Employee> getAllEmployeeInfo();

}
