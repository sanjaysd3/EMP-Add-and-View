package com.emp.service;

import java.util.ArrayList;

import com.emp.bean.Employee;

public interface IEmpService {

	int addEmployeeDetails(Employee emp);

	ArrayList<Employee> getAllEmployeeInfo();

}
